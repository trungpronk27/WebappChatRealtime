-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 16, 2021 lúc 03:43 AM
-- Phiên bản máy phục vụ: 10.3.16-MariaDB
-- Phiên bản PHP: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `chat_spring`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comment_reply`
--

CREATE TABLE `comment_reply` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `conversation`
--

CREATE TABLE `conversation` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user1` int(11) DEFAULT NULL,
  `user2` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `conversation`
--

INSERT INTO `conversation` (`id`, `created_at`, `updated_at`, `user1`, `user2`) VALUES
(1, NULL, NULL, 1, 2),
(3, NULL, NULL, 1, 3),
(4, NULL, NULL, 1, 4);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `employee`
--

CREATE TABLE `employee` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `friend`
--

CREATE TABLE `friend` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `friend_reply` int(11) DEFAULT NULL,
  `friend_send` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `friend`
--

INSERT INTO `friend` (`id`, `created_at`, `updated_at`, `status`, `friend_reply`, `friend_send`) VALUES
(1, NULL, '2021-03-14 07:30:55', 2, 2, 1),
(2, '2021-03-14 14:42:32', '2021-03-14 14:42:32', 2, 1, 3),
(5, NULL, '2021-03-15 09:32:50', 0, 4, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `group_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `group_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `groups`
--

INSERT INTO `groups` (`id`, `created_at`, `updated_at`, `group_img`, `group_name`) VALUES
(1, '2021-03-12 08:22:01', '2021-03-12 08:22:01', 'default.jpg', 'Nhóm chat 1'),
(2, '2021-03-12 08:22:19', '2021-03-12 08:22:19', 'default.jpg', 'Nhóm chat 2'),
(3, '2021-03-12 08:47:02', '2021-03-12 08:47:02', 'default.jpg', 'Nhóm chat 3');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `group_user`
--

CREATE TABLE `group_user` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_admin` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `group_user`
--

INSERT INTO `group_user` (`id`, `created_at`, `updated_at`, `is_admin`, `group_id`, `user_id`) VALUES
(1, '2021-03-12 08:22:01', '2021-03-12 08:22:01', 1, 1, 1),
(2, '2021-03-12 08:22:19', '2021-03-12 08:22:19', 1, 2, 2),
(3, '2021-03-12 08:47:02', '2021-03-12 08:47:02', 1, 3, 1),
(4, NULL, NULL, 0, 1, 2),
(5, '2021-03-15 06:14:59', '2021-03-15 06:14:59', 0, 1, 3),
(6, '2021-03-15 08:53:57', '2021-03-15 08:53:57', 0, 3, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `messenger`
--

CREATE TABLE `messenger` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_send` int(11) DEFAULT NULL,
  `is_read` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `time_read` datetime DEFAULT NULL,
  `time_send` datetime DEFAULT NULL,
  `cvt_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `messenger`
--

INSERT INTO `messenger` (`id`, `created_at`, `updated_at`, `content`, `user_send`, `is_read`, `start_time`, `time_read`, `time_send`, `cvt_id`) VALUES
(1, '2021-03-12 06:50:37', '2021-03-12 06:50:37', 'hey', 1, 1, '2021-03-12 06:50:37', '2021-03-15 09:17:41', '2021-03-12 06:50:37', 1),
(2, '2021-03-12 07:00:40', '2021-03-12 07:00:40', 'alo', 1, 1, NULL, '2021-03-15 09:17:41', '2021-03-12 07:00:40', 1),
(3, '2021-03-12 07:00:51', '2021-03-12 07:00:51', 'gì', 2, 1, NULL, '2021-03-15 06:30:50', '2021-03-12 07:00:51', 1),
(4, '2021-03-12 07:14:03', '2021-03-12 07:14:03', '😒😒', 1, 1, NULL, '2021-03-15 09:17:41', '2021-03-12 07:14:03', 1),
(5, '2021-03-15 02:26:48', '2021-03-15 02:26:48', '😀', 1, 1, '2021-03-15 02:26:48', '2021-03-15 09:17:41', '2021-03-15 02:26:48', 1),
(6, '2021-03-15 02:29:51', '2021-03-15 02:29:51', '😊', 1, 1, NULL, '2021-03-15 09:17:41', '2021-03-15 02:29:51', 1),
(7, '2021-03-15 05:36:00', '2021-03-15 05:36:00', 'p', 1, 1, '2021-03-15 05:36:00', '2021-03-15 05:42:57', '2021-03-15 05:36:00', 3),
(8, '2021-03-15 05:40:29', '2021-03-15 05:40:29', 'hey bạn', 3, 1, NULL, '2021-03-15 08:09:18', '2021-03-15 05:40:29', 3),
(9, '2021-03-15 05:40:58', '2021-03-15 05:40:58', '😊', 3, 1, NULL, '2021-03-15 08:09:18', '2021-03-15 05:40:58', 3),
(10, '2021-03-15 05:41:39', '2021-03-15 05:41:39', '😢', 3, 1, NULL, '2021-03-15 08:09:18', '2021-03-15 05:41:39', 3),
(11, '2021-03-15 05:42:57', '2021-03-15 05:42:57', '❤️', 3, 1, NULL, '2021-03-15 08:09:18', '2021-03-15 05:42:57', 3),
(12, '2021-03-15 05:43:20', '2021-03-15 05:43:20', '❤️', 2, 1, NULL, '2021-03-15 06:30:50', '2021-03-15 05:43:20', 1),
(13, '2021-03-15 05:43:28', '2021-03-15 05:43:28', '😘', 2, 1, NULL, '2021-03-15 06:30:50', '2021-03-15 05:43:28', 1),
(14, '2021-03-15 05:55:08', '2021-03-15 05:55:08', 'hi', 1, 0, NULL, NULL, '2021-03-15 05:55:08', 3),
(15, '2021-03-15 09:17:41', '2021-03-15 09:17:41', 'hey', 2, 0, NULL, NULL, '2021-03-15 09:17:41', 1),
(16, '2021-03-15 09:18:54', '2021-03-15 09:18:54', '😘', 4, 1, '2021-03-15 09:18:54', '2021-03-15 09:26:10', '2021-03-15 09:18:54', 4);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mess_group`
--

CREATE TABLE `mess_group` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_user_send` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `time_read` datetime DEFAULT NULL,
  `time_send` datetime DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `mess_group`
--

INSERT INTO `mess_group` (`id`, `created_at`, `updated_at`, `content`, `group_user_send`, `start_time`, `time_read`, `time_send`, `group_id`) VALUES
(1, '2021-03-15 05:19:52', '2021-03-15 05:19:52', '😁', 1, '2021-03-15 05:19:52', NULL, '2021-03-15 05:19:52', 1),
(2, '2021-03-15 05:24:14', '2021-03-15 05:24:14', '☺️', 1, '2021-03-15 05:24:14', NULL, '2021-03-15 05:24:14', 3),
(3, '2021-03-15 05:24:17', '2021-03-15 05:24:17', '😚', 1, NULL, NULL, '2021-03-15 05:24:17', 3),
(4, '2021-03-15 05:24:43', '2021-03-15 05:24:43', '😛', 1, NULL, NULL, '2021-03-15 05:24:43', 1),
(5, '2021-03-15 05:25:48', '2021-03-15 05:25:48', '😘', 1, NULL, NULL, '2021-03-15 05:25:48', 3),
(6, '2021-03-15 08:54:18', '2021-03-15 08:54:18', '😊', 2, NULL, NULL, '2021-03-15 08:54:18', 3),
(7, '2021-03-15 08:54:24', '2021-03-15 08:54:24', '💋', 2, NULL, NULL, '2021-03-15 08:54:24', 3),
(8, '2021-03-15 09:06:15', '2021-03-15 09:06:15', '❤️❤️❤️', 2, NULL, NULL, '2021-03-15 09:06:15', 1),
(9, '2021-03-15 09:06:37', '2021-03-15 09:06:37', '💋💋', 2, NULL, NULL, '2021-03-15 09:06:37', 1),
(10, '2021-03-15 09:51:06', '2021-03-15 09:51:06', '😝', 2, NULL, NULL, '2021-03-15 09:51:06', 1),
(11, '2021-03-15 09:56:44', '2021-03-15 09:56:44', 'hey', 1, NULL, NULL, '2021-03-15 09:56:44', 3);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `post_img` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `post`
--

INSERT INTO `post` (`id`, `created_at`, `updated_at`, `post_img`, `post_text`, `user_id`) VALUES
(1, '2021-03-14 07:25:53', '2021-03-14 07:25:53', 'n7tVLFF.jpg', 'hmmmmmmmmmmmm!', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `role`
--

INSERT INTO `role` (`id`, `created_at`, `updated_at`, `name`) VALUES
(1, '2021-03-12 06:31:55', '2021-03-12 06:31:55', 'ROLE_ADMIN'),
(2, '2021-03-12 06:31:55', '2021-03-12 06:31:55', 'ROLE_MEMBER');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `time_active` datetime DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`id`, `created_at`, `updated_at`, `time_active`, `date_of_birth`, `email`, `first_name`, `gender`, `last_name`, `password`, `remember_token`, `reset_password_token`, `user_img`, `username`) VALUES
(1, '2021-03-12 06:31:55', '2021-03-15 02:43:03', '2021-03-15 09:56:46', '2000-10-25', 'tranvanhoanghai2510@gmail.com', 'Hải', '0', 'Hoàng', '$2a$10$P7CmReIDZzrabR0kkCSdD.ASQckEmmXwZ65Let4OXKBbOCN8kiTKG', NULL, NULL, 'hai.jpg', 'hoanghai'),
(2, '2021-03-12 06:31:55', '2021-03-12 06:31:55', '2021-03-15 09:51:25', NULL, 'hai@gmail.com', 'Hoàng', NULL, 'Văn', '$2a$10$T1/RcmsOriXch8FSuCcE/uUtio7y/FyzONSdryLj4tGVDNQ/OBvNC', NULL, NULL, 'default.jpg', 'hai'),
(3, '2021-03-14 07:42:22', '2021-03-14 07:42:22', '2021-03-15 05:42:54', NULL, 'trung@gmail.com', 'Trung', NULL, 'Văn ', '$2a$10$tndObytRpjLcQlJR2y2AYejlZAld5V1pPqVkC6YOZUN7s5ktYdBH.', NULL, NULL, 'default.jpg', 'trung'),
(4, '2021-03-14 08:09:43', '2021-03-14 08:09:43', '2021-03-15 09:49:12', NULL, 'yen@gmail.com', 'Yên', NULL, 'Phước ', '$2a$10$C3tyQ.CH8mYfXtbZYDoFqOYc3M7bcfASpgW6JFM.PlJBFB.rM9vCi', NULL, NULL, 'default.jpg', 'yen');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user_role`
--

CREATE TABLE `user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKrsujrovse0o1wa99lfyhnlevp` (`post_id`),
  ADD KEY `FK8kcum44fvpupyw6f5baccx25c` (`user_id`);

--
-- Chỉ mục cho bảng `comment_reply`
--
ALTER TABLE `comment_reply`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKjq5b6rqpn30c58kqrbv7k3ocs` (`comment_id`),
  ADD KEY `FKsrjwcmm9boromh00gubiqc8x5` (`user_id`);

--
-- Chỉ mục cho bảng `conversation`
--
ALTER TABLE `conversation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKgvxo16fc2893m1wradl70t2ie` (`user1`),
  ADD KEY `FKrd8ss2bgw5pr74at0dnilmorr` (`user2`);

--
-- Chỉ mục cho bảng `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `friend`
--
ALTER TABLE `friend`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKanjxpvohiwb8ahgs9gq6li86n` (`friend_reply`),
  ADD KEY `FKky47nhcjy005jkn0bnyff9yo0` (`friend_send`);

--
-- Chỉ mục cho bảng `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `group_user`
--
ALTER TABLE `group_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKm4p7t99vp509n4lt2et6hqkgn` (`group_id`),
  ADD KEY `FK6u7jb50qa69gr3505uttxm86x` (`user_id`);

--
-- Chỉ mục cho bảng `messenger`
--
ALTER TABLE `messenger`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKmx2691auqpbdugfupxpq9kgch` (`cvt_id`),
  ADD KEY `FK3n127p2r10u3p384k4yf6cdcw` (`user_send`);

--
-- Chỉ mục cho bảng `mess_group`
--
ALTER TABLE `mess_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKe0vutxrn8ydayotyqgwbpnawe` (`group_id`),
  ADD KEY `FK83joy45er8au26ch1vrxcgoyo` (`group_user_send`);

--
-- Chỉ mục cho bảng `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK72mt33dhhs48hf9gcqrq4fxte` (`user_id`);

--
-- Chỉ mục cho bảng `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  ADD UNIQUE KEY `UK_sb8bbouer5wak8vyiiy4pf2bx` (`username`);

--
-- Chỉ mục cho bảng `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `FKa68196081fvovjhkek5m97n3y` (`role_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `comment_reply`
--
ALTER TABLE `comment_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `conversation`
--
ALTER TABLE `conversation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `employee`
--
ALTER TABLE `employee`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `friend`
--
ALTER TABLE `friend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `group_user`
--
ALTER TABLE `group_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `messenger`
--
ALTER TABLE `messenger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT cho bảng `mess_group`
--
ALTER TABLE `mess_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
